import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const Dashboard = () => {
    const { user, ready } = useAuth()

    if (!ready) return null
    if (!user) return <Navigate to="/login" replace />

    return (
        <div className="mx-auto max-w-[720px] px-gutter py-24 text-center">
            <h1 className="text-page-title-mobile">Welcome back, {user.name}.</h1>
            <p className="mt-stack-sm text-body text-on-surface-variant">
                Mission Control, Telemetry and Analytics land here next.
            </p>
        </div>
    )
}

export default Dashboard