import { motion } from 'framer-motion'
import { FiArrowRight, FiPlayCircle } from 'react-icons/fi'
import {
    PiCompassBold,
    PiRocketLaunchBold,
    PiPlanetBold,
    PiGaugeBold,
    PiChartLineUpBold,
    PiSlidersHorizontalBold,
    PiBroadcastBold,
    PiShieldCheckBold,
    PiPackageBold,
    PiPlugsBold,
    PiCodeBlockBold,

} from 'react-icons/pi'
import { AreaChart, Area, ResponsiveContainer } from 'recharts'
import Globe from '../components/Globe'
import Button from '../components/Button'

const STATS = [
    { value: '99.98%', label: 'Network uptime' },
    { value: '142ms', label: 'Median command latency' },
    { value: '1,240+', label: 'Spacecraft under watch' },
    { value: '24/7', label: 'Mission ops coverage' },
]

const OPERATORS = ['NASA', 'ESA', 'JAXA', 'ISRO', 'SpaceX', 'Rocket Lab']

const LIFECYCLE = [
    { icon: PiCompassBold, title: 'Planning', desc: 'Model trajectories, propellant budgets, and launch windows before a command is sent.' },
    { icon: PiRocketLaunchBold, title: 'Launch', desc: 'Track ascent and separation live, with ground-station handoffs pre-staged.' },
    { icon: PiPlanetBold, title: 'Orbit', desc: 'Confirm acquisition of signal and settle the spacecraft into its operating orbit.' },
    { icon: PiGaugeBold, title: 'Operations', desc: 'Run daily passes, maneuvers, and payload scheduling from one console.' },
    { icon: PiChartLineUpBold, title: 'Analysis', desc: 'Close the loop with telemetry review and anomaly reporting after every phase.' },
]

const CAPABILITIES = [
    { icon: PiSlidersHorizontalBold, title: 'Automated maneuver planning', desc: 'Propose and validate orbit-correction burns with fuel-budget guardrails built in.' },
    { icon: PiBroadcastBold, title: 'Multi-network uplink', desc: 'Fail over across ground-station networks automatically when a pass is at risk.' },
    { icon: PiShieldCheckBold, title: 'Cryptographic security', desc: 'End-to-end encrypted command links with per-mission key rotation.' },
    { icon: PiPackageBold, title: 'Payload orchestration', desc: 'Queue instrument operations against orbit geometry and power budgets.' },
    { icon: PiPlugsBold, title: 'Legacy telemetry bridge', desc: 'Ingest CCSDS and legacy frame formats without touching your ground segment.' },
    { icon: PiCodeBlockBold, title: 'Orbital data API', desc: 'Stream state vectors and health telemetry into your own tools in real time.' },
]

const TELEMETRY_DATA = [
    { t: 0, v: 62 }, { t: 1, v: 68 }, { t: 2, v: 60 }, { t: 3, v: 74 },
    { t: 4, v: 71 }, { t: 5, v: 80 }, { t: 6, v: 76 }, { t: 7, v: 88 },
    { t: 8, v: 83 }, { t: 9, v: 91 }, { t: 10, v: 86 }, { t: 11, v: 94 },
]

const fadeUp = {
    hidden: { opacity: 0, y: 16 },
    show: { opacity: 1, y: 0 },
}

const Home = () => {
    return (
        <div>
            <section className="relative overflow-hidden border-b border-outline-variant bg-grid">
                <div className="absolute inset-0 z-0 flex items-center justify-center">
                    <Globe />
                </div>

                <div
                    className="pointer-events-none absolute inset-0 z-10"
                    style={{
                        background:
                            'radial-gradient(ellipse 60% 55% at 50% 40%, transparent 0%, var(--color-background) 82%)',
                    }}
                />

                <div className="relative z-20 mx-auto flex max-w-[860px] flex-col items-center px-gutter py-24 text-center sm:px-page-padding sm:py-32">
                    <motion.span
                        initial="hidden"
                        animate="show"
                        variants={fadeUp}
                        transition={{ duration: 0.5 }}
                        className="rounded-full border border-outline-variant bg-surface-container px-4 py-1.5 text-caption uppercase tracking-[0.08em] text-on-surface-variant"
                    >
                        Mission operations platform
                    </motion.span>

                    <motion.h1
                        initial="hidden"
                        animate="show"
                        variants={fadeUp}
                        transition={{ duration: 0.5, delay: 0.08 }}
                        className="mt-stack-lg text-page-title-mobile sm:text-hero-title"
                    >
                        One control plane for every spacecraft you fly.
                    </motion.h1>

                    <motion.p
                        initial="hidden"
                        animate="show"
                        variants={fadeUp}
                        transition={{ duration: 0.5, delay: 0.16 }}
                        className="mt-stack-md max-w-[560px] text-body text-on-surface-variant"
                    >
                        Aether unifies telemetry, maneuver planning, and ground-station handoffs into a
                        single real-time console — built for constellations, not just one satellite.
                    </motion.p>

                    <motion.div
                        initial="hidden"
                        animate="show"
                        variants={fadeUp}
                        transition={{ duration: 0.5, delay: 0.24 }}
                        className="mt-stack-lg flex flex-col gap-3 sm:flex-row"
                    >
                        <Button to="/signup" variant="primary" icon={FiArrowRight}>
                            Launch workspace
                        </Button>
                        <Button href="#lifecycle" variant="outline" icon={FiPlayCircle}>
                            See how it works
                        </Button>
                    </motion.div>

                    <motion.div
                        initial="hidden"
                        animate="show"
                        variants={fadeUp}
                        transition={{ duration: 0.5, delay: 0.32 }}
                        className="mt-16 grid w-full max-w-[640px] grid-cols-2 gap-stack-lg sm:grid-cols-4"
                    >
                        {STATS.map((stat) => (
                            <div key={stat.label}>
                                <p className="text-panel-title text-on-surface">{stat.value}</p>
                                <p className="mt-1 text-caption text-on-surface-variant">{stat.label}</p>
                            </div>
                        ))}
                    </motion.div>
                </div>
            </section>

            {/* ---------------- TRUSTED BY ---------------- */}
            <section className="border-b border-outline-variant py-stack-lg">
                <div className="mx-auto max-w-[1440px] px-gutter sm:px-page-padding">
                    <p className="text-center text-caption uppercase tracking-[0.1em] text-on-surface-variant">
                        Built for teams operating at orbital scale
                    </p>
                    <div className="mt-stack-md flex flex-wrap items-center justify-center gap-x-10 gap-y-3">
                        {OPERATORS.map((name) => (
                            <span
                                key={name}
                                className="text-label uppercase tracking-[0.06em] text-on-surface-variant/60 transition-colors hover:text-on-surface-variant"
                            >
                                {name}
                            </span>
                        ))}
                    </div>
                </div>
            </section>

            {/* ---------------- LIFECYCLE ---------------- */}
            <section id="lifecycle" className="border-b border-outline-variant py-24">
                <div className="mx-auto max-w-[1440px] px-gutter sm:px-page-padding">
                    <div className="mx-auto max-w-[560px] text-center">
                        <h2 className="text-page-title-mobile sm:text-page-title">
                            The mission lifecycle, in one workspace
                        </h2>
                        <p className="mt-stack-sm text-body text-on-surface-variant">
                            From first orbit plan to post-mission analysis, Aether keeps every phase on one
                            timeline.
                        </p>
                    </div>

                    <div className="mt-16 grid grid-cols-1 gap-stack-lg sm:grid-cols-2 lg:grid-cols-5">
                        {LIFECYCLE.map((step, i) => (
                            <motion.div
                                key={step.title}
                                initial={{ opacity: 0, y: 16 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true, margin: '-80px' }}
                                transition={{ duration: 0.4, delay: i * 0.06 }}
                                className="relative border-t border-outline-variant pt-stack-md"
                            >
                                <step.icon size={20} className="text-primary" />
                                <h3 className="mt-stack-sm text-panel-title">{step.title}</h3>
                                <p className="mt-1 text-caption text-on-surface-variant">{step.desc}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ---------------- CAPABILITIES ---------------- */}
            <section className="border-b border-outline-variant py-24">
                <div className="mx-auto max-w-[1440px] px-gutter sm:px-page-padding">
                    <div className="grid grid-cols-1 gap-16 lg:grid-cols-[1fr_1fr]">
                        <div>
                            <h2 className="text-page-title-mobile sm:text-page-title">
                                Built for orbital-scale operations
                            </h2>
                            <p className="mt-stack-sm max-w-[440px] text-body text-on-surface-variant">
                                Every subsystem your ops team touches, wired into one control plane.
                            </p>

                            <div className="mt-stack-lg divide-y divide-outline-variant border-t border-outline-variant">
                                {CAPABILITIES.map((item) => (
                                    <div key={item.title} className="flex gap-4 py-stack-md">
                                        <item.icon size={20} className="mt-1 shrink-0 text-primary" />
                                        <div>
                                            <h3 className="text-label text-on-surface">{item.title}</h3>
                                            <p className="mt-1 text-caption text-on-surface-variant">{item.desc}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <motion.div
                            initial={{ opacity: 0, y: 16 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true, margin: '-80px' }}
                            transition={{ duration: 0.5 }}
                            className="h-fit rounded-lg border border-outline-variant bg-surface-container p-panel-gap lg:sticky lg:top-24"
                        >
                            <div className="flex items-center gap-2">
                                {/* <PiActivityBold size={18} className="text-secondary" /> */}
                                <h3 className="text-panel-title">Downlink signal</h3>
                                <span className="ml-auto flex items-center gap-1.5 text-caption text-secondary">
                                    <span className="h-1.5 w-1.5 rounded-full bg-secondary" />
                                    live
                                </span>
                            </div>

                            <div className="mt-stack-md h-40">
                                <ResponsiveContainer width="100%" height="100%">
                                    <AreaChart data={TELEMETRY_DATA}>
                                        <defs>
                                            <linearGradient id="signal" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.05} />
                                                <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
                                            </linearGradient>
                                        </defs>
                                        <Area
                                            type="monotone"
                                            dataKey="v"
                                            stroke="var(--color-primary)"
                                            strokeWidth={2}
                                            fill="url(#signal)"
                                        />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </div>

                            <div className="mt-stack-md grid grid-cols-3 gap-stack-sm border-t border-outline-variant pt-stack-md">
                                <div>
                                    <p className="text-caption text-on-surface-variant">SNR</p>
                                    <p className="text-label text-on-surface">18.4 dB</p>
                                </div>
                                <div>
                                    <p className="text-caption text-on-surface-variant">Pass</p>
                                    <p className="text-label text-on-surface">04:12 left</p>
                                </div>
                                <div>
                                    <p className="text-caption text-on-surface-variant">Station</p>
                                    <p className="text-label text-on-surface">Svalbard</p>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* ---------------- CTA ---------------- */}
            <section className="py-24">
                <div className="mx-auto max-w-[720px] px-gutter text-center sm:px-page-padding">
                    <h2 className="text-page-title-mobile sm:text-page-title">
                        Ready to fly your next mission on Aether?
                    </h2>
                    <p className="mt-stack-sm text-body text-on-surface-variant">
                        Set up a workspace in minutes — no ground segment migration required.
                    </p>
                    <div className="mt-stack-lg flex flex-col justify-center gap-3 sm:flex-row">
                        <Button to="/signup" variant="primary" icon={FiArrowRight}>
                            Launch workspace
                        </Button>
                        <Button href="mailto:ops@aether.dev" variant="outline">
                            Talk to ops team
                        </Button>
                    </div>
                </div>
            </section>
        </div>
    )
}

export default Home